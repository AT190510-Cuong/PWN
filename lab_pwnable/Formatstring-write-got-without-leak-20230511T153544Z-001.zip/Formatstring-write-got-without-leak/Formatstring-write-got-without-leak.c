#include <stdio.h>
#include <stdlib.h>

int cat_flag()
{
system("cat flag");
while (1<2)
{}
}

void vun()
{
char buff[1024];
read(0, buff, 1000);
printf(buff);
exit(0);
}

int main ()
{
vun();
return 0;
}
